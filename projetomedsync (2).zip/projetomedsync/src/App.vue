<template>
  <div class="image-container">
    <header class="header">
      <img src="./assets/medsync.png" alt="Logo Miniatura" class="logo" width="60" />
      <nav class="navbar">
        <ul>
          <li>
            <router-link to="/">Início</router-link>
          </li>
          <li>
            <router-link to="/duvidas">Dúvidas</router-link>
          </li>
          <li>
            <router-link to="/quem-somos">Quem Somos</router-link>
          </li>
          <li>
            <router-link to="/login" class="entrar-btn">Entrar</router-link>
          </li>
        </ul>
      </nav>
    </header>
    <div class="image-container">
      <img src="./assets/semfundo.png" alt="Imagem ao centro" class="image-center" />
      <img src="./assets/medico.png" alt="Imagem Sobreposta" class="image-overlay" />
    </div>
    <div class="text-overlay">
      <h1>Conectando sua Saúde</h1>
      <h3 class="sub-title">
        Integrando Histórias,<br />
        Transformando Vidas.
      </h3>
      <router-link to="/cadastro" class="cadastro">Cadastrar</router-link>
    </div>
     <main class="content">
      <router-view></router-view>
    </main>
    <footer class="footer">
      <div class="footer-content">
        <div class="contact-info">
          <p><strong>SAC:</strong> 0800-123-456</p>
          <p><strong>CNPJ:</strong> 12.345.678/0001-90</p>
        </div>
        <div class="footer-bottom">
          <p>&copy; 2024 Sua Empresa. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  </div>
</template>

<script setup lang="ts">
import { RouterLink, RouterView } from "vue-router";
</script>

<style scoped>
header {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 80px; /* Define a altura do cabeçalho */
  padding: 0 20px;
  background-color: #fff; /* Define a cor de fundo do cabeçalho */
  z-index: 5;
}
.text-overlay {
  position: absolute;
  top: 10%;
  left: 1%;
  color: #100049;
  padding: 5%;
  font-size: 1.5rem;
  font-weight: bold;
}

.text-overlay h1 {
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5); /* Adiciona sombra ao texto */
}

.sub-title {
  margin: 5% 1 0;
  font-size: 1.8rem;
  font-weight: bold;
  margin-left: 5rem;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5); /* Adiciona sombra ao subtítulo */
}

.image-container {
  position: relative;
  width: 100%;
  height: auto;
  overflow: hidden;
  margin-top: 30px; /* Adiciona espaço entre o menu e as imagens */
}

.image-center {
  width: 100%;
  height: auto;
}

.image-overlay {
  position: absolute;
  top: 0;
  right: 0;
  width: 40%;
  z-index: 1;
}

.text-overlay {
  position: absolute;
  top: 10%;
  left: 5%;
  color: #100049;
  padding: 5%;
  font-size: 1.5rem;
  font-weight: bold;
  z-index: 2;
}

.cadastro {
  border-color: #100049;
  border-radius: 100px;
  background-color: #100049;
  color: #fff;
  text-decoration: none;
  text-align: center;
  font-size: 1.5rem;
  padding: 1rem 1rem;
  margin-left: 3rem;
  margin-top: rem;
  line-height: 1;
  width: 300px;
  display: grid;
}


.logo {
  display: grid;
  margin: 4 auto 2rem;
  position: relative;
}

.container {
  position: relative;
  width: 100%;
  height: 100vh;
  overflow: hidden;
}


nav {
  display: flex;
  justify-content: center; /* Centraliza o menu horizontalmente */
  align-items: center; /* Centraliza os itens do menu verticalmente */
  padding: 10px 0; /* Adiciona espaço ao redor do menu */
  font-family: 'Poppins', sans-serif;
}

nav ul {
  display: flex;
  justify-content: center; /* Garante que os itens dentro do menu sejam centralizados */
  padding: 0;
  margin: 0;
  list-style-type: none;
}

nav a {
  display: inline-block;
  padding: 0.5rem 2rem; /* Ajusta o espaçamento interno dos links */
  text-decoration: none;
  color: #1C2B5A;
  font-weight: bold;
  font-size: 1.2rem;
  transition: background-color 0.3s ease, color 0.3s ease;
  white-space: nowrap; /* Evita quebra de linha nos links */
  margin: 0 10px; /* Espaçamento horizontal entre os itens */
}

nav a.router-link-exact-active {
  color: #1C2B5A;
  font-weight: bold;
}

nav a:hover {
  background-color: rgba(33, 191, 157, 0.1); /* Cor de fundo no hover */
  border-radius: 10px;
}

nav a.entrar-btn {
  background-color: #1C2B5A;
  color: white;
  border-radius: 20px;
  font-size: 1.5rem;
  font-weight: bold;
  text-align: center;
  padding: 0.5rem 1.5rem; /* Ajusta o espaçamento interno do botão */
  margin-left: 30px; /* Espaço à esquerda do botão "Entrar" */
}

nav a.entrar-btn:hover {
  background-color: #21BF9D;
  color: white;
}

@media (min-width: 1024px) {
  header {
    display: flex;
    place-items: center;
    padding-right: calc(var(--section-gap) / 2);
  }

  @media (max-width: 768px) {
    header {
      flex-direction: column;
    }

    .icon {
      width: 30px;
      height: 30px;
    }
  }

  .logo {
    margin: rem 0 0;
  }

  header .wrapper {
    display: inline;
    place-items: flex-start;
    flex-wrap: wrap;
  }

  nav ul {
    display: flex;
    justify-content: center;
    padding: 0;
    margin: 0;
    list-style-type: none;
  }

  nav {
    display: flex;
    justify-content: center;
    align-items: center;
    list-style-type: none;
    padding: 16rem;
    margin: 0.1;
    font-weight: bold;
  }
}


.footer {
  background-color: #e0e0e0;
  padding: 2rem 0;
  text-align: center;
  font-family: Arial, sans-serif;
  color: #1C2B5A;
  font-size: 1.1rem;
  line-height: 2rem;
  z-index: 10;
  position: relative;
  margin-top: 3rem;
}

.footer-content {
  position: relative;
  z-index: 10;
}

.footer p {
  margin: 0.5rem 0;
}
</style>
