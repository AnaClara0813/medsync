import { createRouter, createWebHistory } from 'vue-router';
import Home from '../components/HomeView.vue';
import Sobrenos from '../views/Sobrenos.vue';
import quemsomos from '../views/quemsomos.vue';
import Duvidas from '../views/Duvidas.vue';
import Login from '../views/Login.vue';
import Registro from '../views/Registro.vue';
import Contato from '../views/Contato.vue';
import Pacientes from '../views/Pacientes.vue';
import Medicos from '../views/Medicos.vue';
import Hospitais from '../views/Hospitais.vue';

const routes = [
  { path: '/', name: 'home', component: Home },
  { path: '/quem-somos', name: 'QuemSomos', component: quemsomos },
  { path: '/sobrenos', name: 'sobrenos', component: Sobrenos },
  { path: '/duvidas', name: 'duvidas', component: Duvidas },
  { path: '/login', name: 'login', component: Login },
  { path: '/registro', name: 'registro', component: Registro },
  { path: '/contato', name: 'contato', component: Contato },
  { path: '/medicos', name: 'medicos', component: Medicos },
  { path: '/hospitais', name: 'hospitais', component: Hospitais },
  { path: '/pacientes', name: 'pacientes', component: Pacientes }
];

const router = createRouter({
  history: createWebHistory(),
  routes,
  scrollBehavior(to, from, savedPosition) {
    if (savedPosition) {
      return savedPosition;
    } else {
      return { top: 0 }; // Certifique-se de que a rolagem está sempre para o topo
    }
  }
});

export default router;
