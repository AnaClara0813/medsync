<template>
  <div class="duvidas">
    <h1>Dúvidas</h1>
    <h3>O que é MedSync?</h3>
    <p>O MedSync é uma plataforma de integração de dados e exames de pacientes que conecta médicos, hospitais e pacientes da rede pública e privada. O sistema permite a visualização, gerenciamento e compartilhamento de informações de saúde e exames, facilitando a colaboração entre os profissionais de saúde e proporcionando acesso centralizado para os pacientes.</p>
    <h3>Quem pode usar o MedSync?</h3>
    <p>O MedSync é projetado para ser usado por médicos, hospitais e pacientes. Médicos e hospitais podem acessar e compartilhar informações de exames e dados de pacientes, enquanto os pacientes podem visualizar seus próprios dados de saúde e exames, bem como interagir com os profissionais de saúde.</p>
    <h3>É compatível com todos sistemas hospitalares?</h3>
    <p>O MedSync é projetado para ser compatível com uma ampla gama de sistemas hospitalares e de gerenciamento de saúde. Utilizamos padrões de interoperabilidade, como HL7 e FHIR, para garantir que o MedSync possa se integrar com diferentes sistemas e plataformas de saúde. No entanto, a compatibilidade pode variar e alguns sistemas podem exigir personalizações específicas.</p>
    <h3>Como cadastrar meu hospital?</h3>
    <p>Para cadastrar sua clínica ou hospital no MedSync, você deve entrar em contato com a equipe de suporte ou comercial do MedSync. Eles fornecerão informações sobre o processo de integração, incluindo requisitos técnicos, acordos de parceria e etapas necessárias para conectar sua instituição à plataforma.</p>
    
  </div>
</template>

<style>
@media (min-width: 1024px) {
  .about {
    min-height: 100vh;
    display: inline;
    align-items: center;
  }
}
</style>
