<template>
  <div class="register-container">
    <form @submit.prevent="handleRegister" class="register-form">
     <h1>Cadastro</h1>
      <div class="form-group">
        <label for="name">Nome:</label>
        <input 
          type="text" 
          id="name" 
          v-model="name" 
          placeholder="Digite seu nome" 
          required 
        />
      </div>
      <div class="form-group">
        <label for="dob">Data de Nascimento:</label>
        <input 
          type="date" 
          id="dob" 
          v-model="dob" 
          required 
        />
      </div>
      <div class="form-group">
        <label for="cpf">CPF:</label>
        <input 
          type="text" 
          id="cpf" 
          v-model="cpf" 
          placeholder="Digite seu CPF" 
          required 
        />
      </div>
      <div class="form-group">
        <label for="address">Endereço:</label>
        <input 
          type="text" 
          id="address" 
          v-model="address" 
          placeholder="Digite seu endereço" 
          required 
        />
      </div>
      <div class="form-group">
        <label for="gender">Gênero:</label>
        <select id="gender" v-model="gender" required>
          <option value="" disabled>Selecione o gênero</option>
          <option value="masculino">Masculino</option>
          <option value="feminino">Feminino</option>
          <option value="outro">Outro</option>
        </select>
      </div>
      <div class="form-group">
        <label for="phone">Telefone:</label>
        <input 
          type="tel" 
          id="phone" 
          v-model="phone" 
          placeholder="Digite seu telefone" 
          required 
        />
      </div>
      <div class="form-group">
        <label for="email">E-mail:</label>
        <input 
          type="email" 
          id="email" 
          v-model="email" 
          placeholder="Digite seu e-mail" 
          required 
        />
      </div>
      <div class="form-group">
        <label for="password">Senha:</label>
        <input 
          type="password" 
          id="password" 
          v-model="password" 
          placeholder="Digite sua senha" 
          required 
        />
      </div>
      <div class="form-group">
        <button type="submit" class="register-button">Cadastrar</button>
      </div>
    </form>
  </div>
</template>
<script setup>
import { ref } from 'vue';

const name = ref('');
const dob = ref('');
const cpf = ref('');
const address = ref('');
const gender = ref('');
const phone = ref('');
const email = ref('');
const password = ref('');

const handleRegister = () => {
  // Lógica para o registro do usuário
  console.log('Registro com', { name: name.value, dob: dob.value, cpf: cpf.value, address: address.value, gender: gender.value, phone: phone.value, email: email.value, password: password.value });
  // Exemplo: Redirecionar após o registro
  // router.push('/login');
};
</script>
<style scoped>
.register-container {
  display: -ms-flexbox;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: #ffffff; /* Cor de fundo para contraste */
}

.register-form {
  max-width: 800px; /* Aumentado de 600px para 800px */
  width: 100%;
  padding: 20px;
  background: #ebebeb; /* Cor de fundo do formulário */
  border-radius: 8px;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
  color: #333; /* Cor do texto */
}

h1 {
  text-align: center;
  color: rgb(29, 0, 97); /* Cor do título */
  margin-bottom: 20px;
}

.form-group {
  margin-bottom: 15px;
}

label {
  display: block;
  margin-bottom: 5px;
  font-weight: bold;
  color: #555; /* Cor do texto dos labels */
}

input, select {
  width: 100%;
  padding: 12px;
  border: 1px solid rgb(255, 255, 255); /* Cor da borda dos campos */
  border-radius: 4px;
  box-sizing: border-box;
  font-size: 16px;
}

input:focus, select:focus {
  border-color: #07191c; /* Cor da borda ao focar */
  outline: none;
}

.register-button {
  width: 100%;
  padding: 12px;
  background-color: #048fb9; /* Cor do botão */
  color: white;
  border: none;
  border-radius: 4px;
  font-size: 16px;
  cursor: pointer;
  transition: background-color 0.3s;
}

.register-button:hover {
  background-color: #0056b3; /* Cor do botão ao passar o mouse */
}
</style>
