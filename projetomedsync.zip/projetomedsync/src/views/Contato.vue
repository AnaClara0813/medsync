<template>
  <div class="contato">
    <h1>Olá em que podemos ajudar?</h1>
    <h2>Qual é a sua dúvida, sugestão ou reclamação?</h2>
    <h3>Estamos aqui para resolver!<br>
O atendimento é personalizado<br>
para Beneficiários da Unimed Anápolis!<br>
Basta entrar em contato pelo número gratuito:</h3>
    <h4>SAC</h4>
    <h5>73627463287468372</h5>
    <h4>CNPJ</h4>
    <h5>CNPJ: 03.487.876/0001-56</h5>    
  </div>
</template>

<style>
@media (min-width: 1024px) {
  .about {
    min-height: 100vh;
    display: inline;
    align-items: center;
  }
}
</style>
