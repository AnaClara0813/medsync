import { createRouter, createWebHistory } from 'vue-router';
import Home from '../components/HomeView.vue';
import Sobrenos from '../views/Sobrenos.vue';
import Duvidas from '../views/Duvidas.vue';
import Login from '../views/Login.vue';
import Registro from '../views/Registro.vue';
import Contato from '../views/Contato.vue';
import Pacientes from '../views/Pacientes.vue'
import Medicos from '../views/Medicos.vue'
import Hospitais from '../views/Hospitais.vue'


const routes = [
  {
    path: '/',
    name: 'home',
    component: Home
  },
  {
    path: '/sobrenos',
    name: 'sobrenos',
    component: Sobrenos
  },
  {
    path: '/duvidas',
    name: 'duvidas',
    component: Duvidas
  },
  {
    path: '/login',
    name: 'login',
    component: Login
  },
  {
    path: '/registro',
    name: 'registro',
    component: Registro
  },
  {
    path: '/contato',
    name: 'contato',
    component: Contato
  },
   {
    path: '/medicos',
    name: 'medicos',
    component: Medicos
  },
   {
    path: '/hospitais',
    name: 'hospitais',
    component: Hospitais
  },
   {
    path: '/pacientes',
    name: 'pacientes',
    component: Pacientes
  }];

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes
});

export default router;
