<template>
  <div>
    <header class="header">
      <img src="./assets/medsync.png" alt="Logo Miniatura" class="logo" width="60" />
      <nav class="navbar">
        <ul>
          <router-link to="/">Início</router-link>
          <router-link to="/duvidas">Dúvidas</router-link>
          <router-link to="/sobrenos">Sobre nós</router-link>
          <router-link to="/login" class="highlight">Entrar</router-link>
        </ul>
      </nav>
    </header>
    <img src="./assets/semfundo.png" alt="Imagem ao centro" class="image-center" width="2000" />
    <img src="./assets/medico.png" alt="Imagem Sobreposta" class="image-overlay" />
    <div class="text-overlay">
      <h1>Conectando sua Saúde</h1>
      <h3 class="sub-title">
        Integrando Histórias,<br />
        Transformando Vidas.
      </h3>
      <router-link to="/cadastro" class="cadastro">Cadastrar</router-link>
    </div>
    <router-view></router-view>
    <footer class="footer">
      <div class="footer-content">
        <div class="contact-info">
          <p><strong>SAC:</strong> 0800-123-456</p>
          <p><strong>CNPJ:</strong> 12.345.678/0001-90</p>
        </div>
        <div class="footer-bottom">
          <p>&copy; 2024 Sua Empresa. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  </div>
</template>



<script setup lang="ts">
import { RouterLink, RouterView } from "vue-router";
</script>

<style scoped>
header {
  line-height: 0;
  max-height: 4vh;
  z-index: 5;
}

.text-overlay {
  position: absolute;
  /* Permite posicionar o texto em relação ao container */
  top: 10%;
  /* Ajuste a distância do topo conforme necessário */
  left: 1%;
  /* Ajuste a distância da borda esquerda conforme necessário */
  color: #100049;
  /* Cor do texto */
  padding: 5%;
  /* Espaçamento interno ao redor do texto */
  font-size: 1.5rem;
  /* Tamanho da fonte */
  font-weight: bold;
}

.sub-title {
  margin: 5% 1 0;
  /* Margem superior para espaçar o subtítulo do título principal */
  font-size: 1.8rem;
  /* Ajuste o tamanho da fonte conforme necessário */
  font-weight: bold;
  /* Peso da fonte normal para o subtítulo */
  margin-left: 5rem;
}

.cadastro {
  border-color: #100049;
  border-radius: 100px;
  background-color: #100049;
  color: #fff;
  text-decoration: none;
  text-align: center;
  font-size: 1.5rem;
  padding: 1rem 1rem;
  /* Corrigido padding */
  margin-left: 3rem;
  margin-top: 3rem;
  /* Ajuste a margem conforme necessário */
  line-height: 1;
  width: 300px;
  /* Ajuste a largura conforme necessário */
  display: grid;
}

.logo {
  display: grid;
  margin: 4 auto 2rem;
  position: relative;
}

.container {
  position: relative;
  width: 100%;
  height: 100vh;
  overflow: hidden;
}


nav a.router-link-exact-active {
  color: rgb(116, 116, 116);
}

nav a.router-link-exact-active:hover {
  background-color: rgb(33, 191, 157);
}

nav a {
  display: inline-block;
  padding: 0.3rem 3rem;
  text-decoration: none;
  border: 5px solid transparent;
  border-left: 5px solid var(--color-border);
}

.image-overlay {
  position: relative;
  right: px;
  top: 50%;
  transform: translateY(-178%);
  width: 40%;
  z-index: 100;
  float: right;
}

.image-center {
  display: block;
  margin: 0 auto;
  position: center;
  right: 5%;
  top: 50%;
  width: 100%
}

nav a:first-of-type {
  border: 4;
}

nav a.highlight {
  border-color: #100049;
  border-radius: 12px;
  background-color: #100049;
  color: #fff;
}

@media (min-width: 1024px) {
  header {
    display: flex;
    place-items: center;
    padding-right: calc(var(--section-gap) / 2);
  }

  /* Exemplo de media query */
  @media (max-width: 768px) {
    header {
      flex-direction: column;
      /* Muda a direção dos itens no cabeçalho para coluna em telas pequenas */
    }

    .icon {
      width: 30px;
      /* Reduz o tamanho dos ícones em telas pequenas */
      height: 30px;
    }
  }


  .logo {
    margin: rem 0 0;
  }

  header .wrapper {
    display: inline;
    place-items: flex-start;
    flex-wrap: wrap;
  }

  nav ul {
    display: flex;
    justify-content: center;
    /* Centraliza a lista de links */
    padding: 0;
    margin: 0;
    list-style-type: none;
    /* Remove os pontos da lista */
  }

  nav {
    display: flex;
    /* Usar flexbox para uma melhor distribuição dos itens */
    justify-content: center;
    /* Centralizar os itens */
    align-items: center;
    /* Alinhar verticalmente os itens */
    list-style-type: none;
    /* Remover marcadores da lista */
    padding: 16rem;
    margin: 0.1;
    font-weight: bold;
  }
}
</style>
